#define SECRET_DEVICE_KEY "c987fad0-d518-4c52-a7e2-78fcf5f3df3b"
#define SECRET_SERVER_URL "http://daq.info.lk/rx"
#define SECRET_SSID "SkyNet"
#define SECRET_PASS "WIFIPASSWORD"
